from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)
CORS(app)  # allow the local frontend (opened as a file or on another port) to call this API

# =========================
# Load model
# =========================
rf_model = joblib.load("random_forest_model.pkl")
model_features = joblib.load("random_forest_model_features.pkl")

if not isinstance(model_features, list):
    model_features = model_features.tolist()

# =========================
# Encoding
# =========================
dayMapping = {
    "Monday": 0,
    "Tuesday": 1,
    "Wednesday": 2,
    "Thursday": 3,
    "Friday": 4,
    "Saturday": 5,
    "Sunday": 6
}

loadMapping = {
    "Light_Load": 0,
    "Medium_Load": 1,
    "Maximum_Load": 2
}

# =========================
# Reference stats (from the training data, Steel_industry_data.csv)
# Used by the frontend to build sensible input ranges/defaults and to
# generate a sample batch for the dashboard without needing a CSV upload.
# =========================
FEATURE_RANGES = {
    "Lagging_Current_Reactive.Power_kVarh": {"min": 0, "max": 96.91, "mean": 13.04, "unit": "kVarh"},
    "Leading_Current_Reactive_Power_kVarh": {"min": 0, "max": 27.76, "mean": 3.87, "unit": "kVarh"},
    "CO2(tCO2)": {"min": 0, "max": 0.07, "mean": 0.0115, "unit": "tCO2"},
    "Lagging_Current_Power_Factor": {"min": 0, "max": 100, "mean": 80.58, "unit": "%"},
    "Leading_Current_Power_Factor": {"min": 0, "max": 100, "mean": 84.37, "unit": "%"},
    "NSM": {"min": 0, "max": 85500, "mean": 42750, "unit": "seconds since midnight"},
}
LOAD_TYPES = list(loadMapping.keys())
DAYS_OF_WEEK = list(dayMapping.keys())
TARGET_RANGE = {"min": 0, "max": 157.18, "mean": 27.39}  # Usage_kWh, for gauge scaling on the frontend

# =========================
# Preprocess
# =========================
def preprocess(df):
    df = df.copy()

    if "WeekStatus" in df.columns:
        df.drop(columns=["WeekStatus"], inplace=True)

    if "Day_of_week" in df.columns:
        day_numeric = df["Day_of_week"].map(dayMapping)

        df["sinDay"] = np.sin(2 * np.pi * day_numeric / 7)
        df["cosDay"] = np.cos(2 * np.pi * day_numeric / 7)

        df.drop(columns=["Day_of_week"], inplace=True)

    if "Load_Type" in df.columns:
        df["Load_Type"] = df["Load_Type"].map(loadMapping)

    df = df[model_features]

    return df


# =========================
# Home
# =========================
@app.route("/")
def home():
    return jsonify({
        "message": "Steel Industry Energy Prediction API",
        "status": "Running"
    })


# =========================
# Reference data for the frontend (ranges, categories, target scale)
# =========================
@app.route("/ranges", methods=["GET"])
def ranges():
    return jsonify({
        "features": FEATURE_RANGES,
        "loadTypes": LOAD_TYPES,
        "daysOfWeek": DAYS_OF_WEEK,
        "target": TARGET_RANGE
    })


# =========================
# Dashboard API
# =========================
@app.route("/dashboard", methods=["POST"])
def dashboard():

    data = request.get_json()

    if not data:
        return jsonify({"error": "No input received"}), 400

    try:

        # Accept single object or list of objects
        if isinstance(data, dict):
            df = pd.DataFrame([data])
        else:
            df = pd.DataFrame(data)

        X = preprocess(df)

        predictions = rf_model.predict(X)

        # Add predictions to dataframe
        result = df.copy()
        result["Predicted_Usage_kWh"] = predictions

        # Summary statistics
        summary = {
            "totalRecords": len(result),
            "averagePrediction": round(float(np.mean(predictions)), 2),
            "maximumPrediction": round(float(np.max(predictions)), 2),
            "minimumPrediction": round(float(np.min(predictions)), 2),
            "standardDeviation": round(float(np.std(predictions)), 2)
        }

        # Chart data
        chartData = []

        for i, value in enumerate(predictions):
            chartData.append({
                "index": i + 1,
                "prediction": round(float(value), 2)
            })

        # Feature importance
        featureImportance = []

        for feature, importance in zip(model_features, rf_model.feature_importances_):
            featureImportance.append({
                "feature": feature,
                "importance": round(float(importance), 4)
            })

        featureImportance.sort(
            key=lambda x: x["importance"],
            reverse=True
        )

        return jsonify({

            "summary": summary,

            "featureImportance": featureImportance,

            "chartData": chartData,

            "predictions": result.to_dict(orient="records")

        })

    except Exception as e:
        return jsonify({
            "error": str(e)
        }), 400


if __name__ == "__main__":
    app.run(host="localhost", port=3000, debug=True)
